cd angular
ng serve
